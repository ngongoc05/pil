/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

/**
 *
 * @author quandba
 */
public class ConstWorker {
    public static final String FILE_NAME = "worker.txt";
    public static final String REGEX_NAME = "[a-zA-Z0-9 ]+"; 
    public static final String REGEX_WORKLOCATION = "[a-zA-Z0-9 ]+";
}
